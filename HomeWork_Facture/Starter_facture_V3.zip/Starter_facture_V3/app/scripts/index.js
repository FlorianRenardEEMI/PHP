import 'flexboxgrid';

document.addEventListener('DOMContentLoaded', () => console.log('scripts loaded'));